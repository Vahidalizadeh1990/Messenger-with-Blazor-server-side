﻿


window.ScrollToBottom = (elementName) => {
    element = document.getElementById(elementName);
    window.scrollTo(0, element.scrollHeight);
}