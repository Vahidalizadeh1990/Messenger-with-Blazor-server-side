﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivateMessenger.Models.ViewModels
{
    /// <summary>
    /// Enum Gender
    /// We can add some other Gender value for this enum
    /// </summary>
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
